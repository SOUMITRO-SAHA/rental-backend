exports.AuthRoles = {
	USER: "USER",
	ADMIN: "ADMIN",
	MANAGER: "MANAGER",
	TENDER: "TENDER",
};

# Tasks

- Wishlist
- rent
- deposite
- photos